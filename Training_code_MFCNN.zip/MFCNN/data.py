import numpy as np
import yuv_import
import os
import gc
import matplotlib.pyplot as plt
import random

h = 64
w = 64

num_cif = 19
num_sif = 2
num_4cif = 5
num_480 = 2
num_720 = 2
num_1080 = 15
num_2048 = 15

Height_cif = 288
Width_cif = 352

Height_sif = 240
Width_sif = 352

Height_4cif = 576
Width_4cif = 704

Height_480 = 480
Width_480 = 720

Height_720 = 720
Width_720 = 1280

Height_1080 = 1080
Width_1080 = 1920

Height_2048 = 1080
Width_2048 = 2048

blk_cif = ((Height_cif-h)//15 + 1)*((Width_cif-w)//15 + 1)
blk_sif = ((Height_sif-h)//15 + 1)*((Width_sif-w)//15 + 1)
blk_4cif = ((Height_4cif-h)//40 + 1)*((Width_4cif-w)//40 + 1)
blk_480 = ((Height_480-h)//40 + 1)*((Width_480-w)//40 + 1)

blk_720 = ((Height_720-h)//40 + 1)*((Width_720-w)//40 + 1)
blk_1080 = ((Height_1080-h)//100 + 1)*((Width_1080-w)//100 + 1)
blk_2048 = ((Height_2048-h)//100 + 1)*((Width_2048-w)//100 + 1)

frame_num = 100

num_sample = (frame_num // 4 - 1)* (num_cif * blk_cif + num_sif * blk_sif + num_4cif * blk_4cif + num_480 * blk_480 + num_720 * blk_720 + num_1080 * blk_1080 + num_2048 * blk_2048)
print(num_sample)

def IsSubString(SubStrList, Str):
    flag = True
    for substr in SubStrList:
        if not (substr in Str):
            flag = False
    return flag

FileNames = os.listdir('D:/YUV_train/')

def shuffle(y1, y2, y3, y4, y5, y6):

      num_examples = len(y1)
      per = np.arange(num_examples)
      np.random.shuffle(per)
      y1 = y1[per[0:320000]]
      y2 = y2[per[0:320000]]
      y3 = y3[per[0:320000]]
      y4 = y4[per[0:320000]]
      y5 = y5[per[0:320000]]
      y6 = y6[per[0:320000]]

      return y1, y2, y3, y4, y5, y6

def init_y(num, hh, ww):
    y1 = np.zeros([num, hh, ww, 1])
    y2 = np.zeros([num, hh, ww, 1])
    y3 = np.zeros([num, hh, ww, 1])
    y4 = np.zeros([num, hh, ww, 1])
    y5 = np.zeros([num, hh, ww, 1])

    y6 = np.zeros([num, hh, ww, 1])

    return y1, y2, y3, y4, y5, y6


def input_data():

    begin_index = 0

    y1, y2, y3, y4, y5, y6 = init_y(num_sample, h, w)

    y1, y2, y3, y4, y5, y6, end_indx = load_video("_cif", num_cif, Height_cif, Width_cif, y1, y2,
                                                                y3, y4, y5, y6, begin_index)
    print([len(y1), end_indx])
    y1, y2, y3, y4, y5, y6, end_indx = load_video("_sif", num_sif, Height_sif, Width_sif, y1, y2,
                                                                y3, y4, y5, y6, end_indx)
    print([len(y1), end_indx])
    y1, y2, y3, y4, y5, y6, end_indx = load_video("_4cif", num_4cif, Height_4cif,
                                                                Width_4cif, y1, y2, y3, y4, y5, y6, end_indx)
    print([len(y1), end_indx])
    y1, y2, y3, y4, y5, y6, end_indx = load_video("_720x480", num_480, Height_480,
                                                                Width_480, y1, y2, y3, y4, y5, y6, end_indx)
    print([len(y1), end_indx])
    y1, y2, y3, y4, y5, y6, end_indx = load_video("_720p", num_720, Height_720,
                                                  Width_720, y1, y2, y3, y4, y5, y6, end_indx)
    print([len(y1), end_indx])

    y1, y2, y3, y4, y5, y6, end_indx = load_video("_1080p", num_1080, Height_1080,
                                                  Width_1080, y1, y2, y3, y4, y5, y6, end_indx)
    print([len(y1), end_indx])

    y1, y2, y3, y4, y5, y6, end_indx = load_video("_2048x1080", num_2048, Height_2048,
                                                  Width_2048, y1, y2, y3, y4, y5, y6, end_indx)
    print([len(y1), end_indx])

    y1, y2, y3, y4, y5, y6 = shuffle(y1, y2, y3, y4, y5, y6)

    np.save("x1_1.npy", y1)
    np.save("x2_1.npy", y2)
    np.save("x3_1.npy", y3)
    np.save("x4_1.npy", y4)
    np.save("x5_1.npy", y5)
    np.save("x6_1.npy", y6)

    return y1, y2, y3, y4, y5, y6, end_indx

def load_video(string, video_num, Height, Width, y1, y2, y3, y4, y5, y6, index_begin):

    video_count = 0
    eg_num = 0
    y1_init, y2_init, y3_init, y4_init, y5_init, y6_init = init_y(video_num * frame_num//4, Height, Width)

    for fn in FileNames:
        if (IsSubString([string], fn)):
            fullfilename = os.path.join('D:/YUV_train/', fn)
            filename = os.path.basename(fullfilename)
            # Height = 288
            # Width = 352

            video_count = video_count + 1

            if video_count <= video_num:

             Y1, U1, V1 = yuv_import.yuv_import("D:/YUV_LDP_QP37/" + filename, (Height, Width), frame_num + 4, 4)
             Y2, U2, V2 = yuv_import.yuv_import("D:/YUV_orig/" + filename, (Height, Width), frame_num + 4, 4)
             nnn = 0;
             for ff in range(frame_num // 4 - 1):

                 y1_init[eg_num + ff : eg_num + ff + 1, 0:Height, 0:Width, 0] = Y1[ff*4 : ff*4 + 1] / 255.0
                 y3_init[eg_num + ff : eg_num + ff + 1, 0:Height, 0:Width, 0] = Y1[(ff + 1)*4 : (ff+1)*4 + 1] / 255.0

                 # y4_init[eg_num + ff : eg_num + ff + 1, 0:Height, 0:Width, 0] = Y2[ff*4 : ff*4 + 1] / 255.0
                 # y6_init[eg_num + ff : eg_num + ff + 1, 0:Height, 0:Width, 0] = Y2[(ff + 1)*4 : (ff+1)*4 + 1] / 255.0

                 ff_delta = 1
                 y2_init[eg_num + ff : eg_num + ff + 1, 0:Height, 0:Width, 0] = Y1[ff*4 + ff_delta : ff*4 + ff_delta + 1] / 255.0
                 y5_init[eg_num + ff : eg_num + ff + 1, 0:Height, 0:Width, 0] = Y2[ff*4 + ff_delta : ff*4 + ff_delta + 1] / 255.0

                 nnn = nnn + 1

                 # y1_init[eg_num + ff: eg_num + ff + 1, 0:Height, 0:Width, 0] = Y1[ff * 4: ff * 4 + 1] / 255.0
                 # y3_init[eg_num + ff: eg_num + ff + 1, 0:Height, 0:Width, 0] = Y1[(ff + 2) * 4: (ff + 2) * 4 + 1] / 255.0
                 #
                 # y4_init[eg_num + ff: eg_num + ff + 1, 0:Height, 0:Width, 0] = Y2[ff * 4: ff * 4 + 1] / 255.0
                 # y6_init[eg_num + ff: eg_num + ff + 1, 0:Height, 0:Width, 0] = Y2[(ff + 2) * 4: (ff + 2) * 4 + 1] / 255.0
                 #
                 # y2_init[eg_num + ff: eg_num + ff + 1, 0:Height, 0:Width, 0] = Y1[(ff + 1) * 4: (ff + 1) * 4 + 1] / 255.0
                 # y5_init[eg_num + ff: eg_num + ff + 1, 0:Height, 0:Width, 0] = Y2[(ff + 1) * 4: (ff + 1) * 4 + 1] / 255.0
                 #
                 # nnn = nnn + 1

                 # print(ff)
                 # print(ff_delta)
                 # frame_show = eg_num + ff;
                 # plt.subplot(131);
                 # plt.imshow(y1_init[frame_show].squeeze(), cmap='gray')
                 # plt.subplot(132);
                 # plt.imshow(y2_init[frame_show].squeeze(), cmap='gray')
                 # plt.subplot(133);
                 # plt.imshow(y3_init[frame_show].squeeze(), cmap='gray')
                 # plt.show()

             eg_num = eg_num + nnn
             print(video_count, eg_num)

             del Y1, Y2, U1, V1
             gc.collect()

            else:
               break

    row = Height//h
    col = Width//w
    nn = 0

    if Height <= 400:
        step = 15
    if Height > 400 and Height < 1000:
        step = 40
    if Height >= 1000:
        step = 100

    row_samp = (Height - h)//step + 1
    col_samp = (Width - w)//step + 1

    for fr in range (eg_num):
        for aa in range(row_samp):
          for bb in range(col_samp):

            y1[index_begin + nn: index_begin +(nn + 1), 0:h, 0:w, 0] = \
                y1_init[fr:fr+1, aa * step: aa * step + h, bb * step: bb * step + w, 0]
            y2[index_begin + nn: index_begin + (nn + 1), 0:h, 0:w, 0] = \
                y2_init[fr:fr + 1, aa * step: aa * step + h, bb * step: bb * step + w, 0]
            y3[index_begin + nn: index_begin + (nn + 1), 0:h, 0:w, 0] = \
                y3_init[fr:fr + 1, aa * step: aa * step + h, bb * step: bb * step + w, 0]
            y4[index_begin + nn: index_begin + (nn + 1), 0:h, 0:w, 0] = \
                y4_init[fr:fr + 1, aa * step: aa * step + h, bb * step: bb * step + w, 0]
            y5[index_begin + nn: index_begin + (nn + 1), 0:h, 0:w, 0] = \
                y5_init[fr:fr + 1, aa * step: aa * step + h, bb * step: bb * step + w, 0]
            y6[index_begin + nn: index_begin + (nn + 1), 0:h, 0:w, 0] = \
                y6_init[fr:fr + 1, aa * step: aa * step + h, bb * step: bb * step + w, 0]

            nn = nn + 1

    index_end = index_begin + nn
    del y1_init, y2_init, y3_init, y4_init, y5_init, y6_init
    gc.collect()
    return y1, y2, y3, y4, y5, y6, index_end
# #
y1, y2, y3, y4, y5, y6, num_sample = input_data()
# #
# np.save("x1.npy", y1)
# np.save("x2.npy", y2)
# np.save("x3.npy", y3)
# np.save("x4.npy", y4)
# np.save("x5.npy", y5)
# np.save("x6.npy", y6)
# # #
# mse_loss = np.mean(np.power(np.subtract(frame, label),2.0))
#
#
# with tf.Session() as sess:
#   sess.run(tf.global_variables_initializer())
#   imgarray = sess.run(frame)
#   # imgarray2 = sess.run(label)

