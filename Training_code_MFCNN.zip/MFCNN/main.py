import numpy as np
import flow
import tensorflow as tf
import scipy.io as sio
import os
from scipy import ndimage
import matplotlib.pyplot as plt
import net
import gc
import data

Height = 64
Width = 64
Channel = 1
batch_size = 64


os.environ['CUDA_VISIBLE_DEVICES']='3'
config = tf.ConfigProto(allow_soft_placement = True)
sess = tf.Session(config = config)

x1 = tf.placeholder(tf.float32, [batch_size, Height, Width, Channel])
x2 = tf.placeholder(tf.float32, [batch_size, Height, Width, Channel])
x3 = tf.placeholder(tf.float32, [batch_size, Height, Width, Channel])

x1_raw = tf.placeholder(tf.float32, [batch_size, Height, Width, Channel])
x2_raw = tf.placeholder(tf.float32, [batch_size, Height, Width, Channel])
x3_raw = tf.placeholder(tf.float32, [batch_size, Height, Width, Channel])

# with tf.variable_scope("flow") as scope:
#   x1_3 = flow.forward(batch_size, x3, x1)
#   scope.reuse_variables()
#   x2_3 = flow.forward(batch_size, x3, x2)
#   scope.reuse_variables()
#   x4_3 = flow.forward(batch_size, x3, x4)
#   scope.reuse_variables()
#   x5_3 = flow.forward(batch_size, x3, x5)

x1to2, x1to2_raw = flow.warp_img(batch_size, x2, x1, x1_raw, False)

x3to2, x3to2_raw = flow.warp_img(batch_size, x2, x3, x3_raw, True)

x2_enhanced = net.network(x1to2, x2, x3to2)

tf.summary.image('output',x2_enhanced)

flow_loss1 = tf.reduce_mean(tf.pow(tf.subtract(x1to2_raw, x2_raw),2.0))
flow_loss2 = tf.reduce_mean(tf.pow(tf.subtract(x3to2_raw, x2_raw),2.0))

flow_loss10 = tf.reduce_mean(tf.pow(tf.subtract(x1to2, x2),2.0))
flow_loss20 = tf.reduce_mean(tf.pow(tf.subtract(x3to2, x2),2.0))

flow_loss = flow_loss1 + flow_loss2

flow_loss0 = flow_loss10 + flow_loss20

mse_loss = tf.reduce_mean(tf.pow(tf.subtract(x2_enhanced, x2_raw),2.0))
total_loss = mse_loss + 0.01 * flow_loss
total_loss_0 = 0.01 * mse_loss + flow_loss

psnr = 10.0*tf.log(1.0/mse_loss)/tf.log(10.0)

mse_loss0 = tf.reduce_mean(tf.pow(tf.subtract(x2, x2_raw),2.0))
psnr0 = 10.0*tf.log(1.0/mse_loss0)/tf.log(10.0)

train_step = tf.train.AdamOptimizer(0.0001).minimize(total_loss)
train_step_0 = tf.train.AdamOptimizer(0.0001).minimize(total_loss_0)
# train_step_1 = tf.train.GradientDescentOptimizer(0.005).minimize(mse_loss)
#
tf.summary.scalar('mse',mse_loss)
tf.summary.scalar('total_loss',total_loss)
tf.summary.scalar('total_loss_0',total_loss_0)
tf.summary.scalar('psnr',psnr)
tf.summary.scalar('psnr_org',psnr0)
tf.summary.scalar('delta_psnr',psnr - psnr0)
tf.summary.scalar('flow_loss',flow_loss)
tf.summary.scalar('flow_loss0',flow_loss0)


summary_writer = tf.summary.FileWriter('F:/yangren/QP42', sess.graph)
saver = tf.train.Saver(max_to_keep=None)
# saver0 = tf.train.Saver()

# sess.run(tf.global_variables_initializer())
saver.restore(sess, 'F:/3_frames_3/model.ckpt-25000')
# sess.graph.finalize()

# frame1, frame2, frame3, frame4, frame5, frame6, num_samples = data.input_data()
frame1 = np.load("x1_sf2.npy")
print("load")
frame2 = np.load("x2_sf2.npy")
print("load")
frame3 = np.load("x3_sf2.npy")
print("load")
frame4 = np.load("x4_sf2.npy")
print("load")
frame5 = np.load("x5_sf2.npy")
print("load")
frame6 = np.load("x6_sf2.npy")
print("load")
num_samples = 320000

batch_num = num_samples //batch_size

print(len(frame1), num_samples, batch_num)

for i in range(batch_num * 20):

    ind = i % batch_num
    train_step_0.run(session=sess, feed_dict={x1: frame1[ind * batch_size:(ind + 1) * batch_size],
                              x2: frame2[ind * batch_size:(ind + 1) * batch_size],
                              x3: frame3[ind * batch_size:(ind + 1) * batch_size],
                              x1_raw: frame4[ind * batch_size:(ind + 1) * batch_size],
                              x2_raw: frame5[ind * batch_size:(ind + 1) * batch_size],
                              x3_raw: frame6[ind*batch_size:(ind+1)*batch_size]})

    if i % 500 == 0:
         merged_summary_op = tf.summary.merge_all()
         summary_str = sess.run(merged_summary_op, feed_dict={x1: frame1[ind*batch_size:(ind+1)*batch_size],
                              x2: frame2[ind * batch_size:(ind + 1) * batch_size],
                              x3: frame3[ind * batch_size:(ind + 1) * batch_size],
                              x1_raw: frame4[ind * batch_size:(ind + 1) * batch_size],
                              x2_raw: frame5[ind * batch_size:(ind + 1) * batch_size],
                              x3_raw: frame6[ind*batch_size:(ind+1)*batch_size]})

         summary_writer.add_summary(summary_str, i)

    if i % 2500 == 0:
          gc.collect()
          checkpoint_path = os.path.join('F:/yangren/QP42', 'model.ckpt')
          saver.save(sess, checkpoint_path, global_step=i)
          print(i)


print("flow over")

for i in range(batch_num * 20):

    ind = i % batch_num
    train_step.run(session=sess, feed_dict={x1: frame1[ind * batch_size:(ind + 1) * batch_size],
                              x2: frame2[ind * batch_size:(ind + 1) * batch_size],
                              x3: frame3[ind * batch_size:(ind + 1) * batch_size],
                              x1_raw: frame4[ind * batch_size:(ind + 1) * batch_size],
                              x2_raw: frame5[ind * batch_size:(ind + 1) * batch_size],
                              x3_raw: frame6[ind*batch_size:(ind+1)*batch_size]})
    if i % 500 == 0:
         merged_summary_op = tf.summary.merge_all()
         summary_str = sess.run(merged_summary_op, feed_dict={x1: frame1[ind*batch_size:(ind+1)*batch_size],
                              x2: frame2[ind * batch_size:(ind + 1) * batch_size],
                              x3: frame3[ind * batch_size:(ind + 1) * batch_size],
                              x1_raw: frame4[ind * batch_size:(ind + 1) * batch_size],
                              x2_raw: frame5[ind * batch_size:(ind + 1) * batch_size],
                              x3_raw: frame6[ind*batch_size:(ind+1)*batch_size]})

         summary_writer.add_summary(summary_str, i + batch_num * 20)

    if i % 2500 == 0:
          gc.collect()
          print(i)
          checkpoint_path = os.path.join('F:/yangren/QP42', 'model.ckpt')
          saver.save(sess, checkpoint_path, global_step=i + batch_num * 50)

