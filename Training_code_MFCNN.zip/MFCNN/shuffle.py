import numpy as np
import yuv_import
import tensorflow as tf
import os
import gc
import matplotlib.pyplot as plt

x1 = np.load("x1_peak.npy")
num_examples = len(x1)
per = np.arange(num_examples)
np.random.shuffle(per)

x1 = x1[per[0:320000]]
np.save("x1_sf_peak.npy", x1)
del x1
gc.collect()

x2 = np.load("x2_peak.npy")
x2 = x2[per[0:320000]]
np.save("x2_sf_peak.npy", x2)
del x2
gc.collect()

x3 = np.load("x3_peak.npy")
x3 = x3[per[0:320000]]
np.save("x3_sf_peak.npy", x3)
del x3
gc.collect()

x4 = np.load("x4_peak.npy")
x4 = x4[per[0:320000]]
np.save("x4_sf_peak.npy", x4)
del x4
gc.collect()

x5 = np.load("x5_peak.npy")
x5 = x5[per[0:320000]]
np.save("x5_sf_peak.npy", x5)
del x5
gc.collect()

x6 = np.load("x6_peak.npy")
x6 = x6[per[0:320000]]
np.save("x6_sf_peak.npy", x6)
del x6
gc.collect()